//
//  TELVerifyFramework.h
//  TELVerifyFramework
//
//  Created by iAmSnow on 3/3/19.
//  Copyright © 2019 True-e-Logistics. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TELVerifyFramework.
FOUNDATION_EXPORT double TELVerifyFrameworkVersionNumber;

//! Project version string for TELVerifyFramework.
FOUNDATION_EXPORT const unsigned char TELVerifyFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TELVerifyFramework/PublicHeader.h>


